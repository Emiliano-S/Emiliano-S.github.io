import{a}from"./chunk-U2YQXRHM.js";import"./chunk-HFBR4SKI.js";export default a();
